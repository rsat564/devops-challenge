#--------------------------------------------------------------
# Terraform Remote State Backend Setup Script (PowerShell)
#
# Creates Azure Storage Account for Terraform state files.
# Run ONCE before any Terraform deployment.
#
# Prerequisites:
#   - Azure CLI installed and authenticated (az login)
#   - Subscription set (az account set --subscription <id>)
#
# Usage:
#   .\scripts\setup-backend.ps1
#--------------------------------------------------------------

$ErrorActionPreference = "Stop"

#--------------------------------------------------------------
# Configuration
#--------------------------------------------------------------
$ResourceGroupName  = "rg-cloudops-tfstate"
$StorageAccountName = "stcloudopstfstate"
$ContainerName      = "tfstate"
$Location           = "eastus"
$Sku                = "Standard_ZRS"

$TagProject   = "cloudops"
$TagManagedBy = "script"
$TagPurpose   = "terraform-state"

#--------------------------------------------------------------
Write-Host "============================================" -ForegroundColor Yellow
Write-Host " Terraform State Backend Setup" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Yellow
Write-Host ""

#--------------------------------------------------------------
# Validate Azure CLI
#--------------------------------------------------------------
Write-Host "[1/6] Validating Azure CLI authentication..." -ForegroundColor Green
try {
    $account = az account show | ConvertFrom-Json
    Write-Host "  Subscription: $($account.name) ($($account.id))"
} catch {
    Write-Host "ERROR: Not logged in. Run 'az login' first." -ForegroundColor Red
    exit 1
}
Write-Host ""

#--------------------------------------------------------------
# Create Resource Group
#--------------------------------------------------------------
Write-Host "[2/6] Creating Resource Group: $ResourceGroupName..." -ForegroundColor Green
az group create `
    --name $ResourceGroupName `
    --location $Location `
    --tags project=$TagProject managedby=$TagManagedBy purpose=$TagPurpose `
    --output none

Write-Host "  Resource Group created in $Location"
Write-Host ""

#--------------------------------------------------------------
# Create Storage Account
#--------------------------------------------------------------
Write-Host "[3/6] Creating Storage Account: $StorageAccountName..." -ForegroundColor Green
az storage account create `
    --name $StorageAccountName `
    --resource-group $ResourceGroupName `
    --location $Location `
    --sku $Sku `
    --kind StorageV2 `
    --min-tls-version TLS1_2 `
    --allow-blob-public-access false `
    --https-only true `
    --tags project=$TagProject managedby=$TagManagedBy purpose=$TagPurpose `
    --output none

Write-Host "  Storage Account created with $Sku redundancy"
Write-Host ""

#--------------------------------------------------------------
# Enable Versioning
#--------------------------------------------------------------
Write-Host "[4/6] Enabling blob versioning..." -ForegroundColor Green
az storage account blob-service-properties update `
    --account-name $StorageAccountName `
    --resource-group $ResourceGroupName `
    --enable-versioning true `
    --enable-delete-retention true `
    --delete-retention-days 30 `
    --output none

Write-Host "  Versioning enabled, soft-delete: 30 days"
Write-Host ""

#--------------------------------------------------------------
# Create Container
#--------------------------------------------------------------
Write-Host "[5/6] Creating blob container: $ContainerName..." -ForegroundColor Green
az storage container create `
    --name $ContainerName `
    --account-name $StorageAccountName `
    --auth-mode login `
    --output none

Write-Host "  Container '$ContainerName' created"
Write-Host ""

#--------------------------------------------------------------
# Lock Resource Group
#--------------------------------------------------------------
Write-Host "[6/6] Adding delete lock..." -ForegroundColor Green
az lock create `
    --name "protect-tfstate" `
    --resource-group $ResourceGroupName `
    --lock-type CanNotDelete `
    --notes "Protects Terraform state backend from accidental deletion" `
    --output none

Write-Host "  Delete lock applied"
Write-Host ""

#--------------------------------------------------------------
# Summary
#--------------------------------------------------------------
Write-Host "============================================" -ForegroundColor Yellow
Write-Host " Setup Complete!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "Backend configuration:"
Write-Host ""
Write-Host "  resource_group_name  = `"$ResourceGroupName`""
Write-Host "  storage_account_name = `"$StorageAccountName`""
Write-Host "  container_name       = `"$ContainerName`""
Write-Host "  key                  = `"<env>/terraform.tfstate`""
Write-Host ""
Write-Host "Initialize Terraform:"
Write-Host ""
Write-Host "  cd infrastructure"
Write-Host "  terraform init -backend-config=environments/dev-eastus.backend.hcl"
Write-Host ""
Write-Host "For large teams, see docs/STATE-MANAGEMENT.md" -ForegroundColor Yellow
