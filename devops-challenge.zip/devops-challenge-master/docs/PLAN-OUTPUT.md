# Terraform Plan Output

## How to Generate Plan Output

```bash
cd infrastructure
terraform init -backend-config=environments/dev-eastus.backend.hcl
terraform plan -var-file=environments/dev-eastus.tfvars -no-color | tee plan-output-dev.txt
```

## Dev Environment Plan Output

> **Note:** The plan below is generated against the `dev` environment using the Azure Free Tier.
> Run `terraform plan -var-file=environments/dev-eastus.tfvars` to reproduce.

```
Terraform used the selected providers to generate the following execution plan.
Resource actions are indicated with the following symbols:
  + create

Terraform will perform the following actions:

  # azurerm_resource_group.this will be created
  + resource "azurerm_resource_group" "this" {
      + id       = (known after apply)
      + location = "eastus"
      + name     = "rg-cloudops-dev-eastus"
      + tags     = {
          + "CostCenter"  = "engineering"
          + "Environment" = "dev"
          + "ManagedBy"   = "terraform"
          + "Owner"       = "platform-team"
          + "Project"     = "cloudops"
          + "Region"      = "eastus"
        }
    }

  # random_string.suffix will be created
  + resource "random_string" "suffix" {
      + id          = (known after apply)
      + length      = 6
      + lower       = true
      + min_lower   = 0
      + min_numeric = 0
      + min_special = 0
      + min_upper   = 0
      + number      = true
      + numeric     = true
      + result      = (known after apply)
      + special     = false
      + upper       = false
    }

  # module.vnet["main"].azurerm_virtual_network.this will be created
  + resource "azurerm_virtual_network" "this" {
      + address_space       = ["10.10.0.0/16"]
      + dns_servers         = []
      + id                  = (known after apply)
      + location            = "eastus"
      + name                = "vnet-main-cloudops-dev-eastus"
      + resource_group_name = "rg-cloudops-dev-eastus"
      + tags                = {
          + "CostCenter"  = "engineering"
          + "Environment" = "dev"
          + "ManagedBy"   = "terraform"
          + "Owner"       = "platform-team"
          + "Project"     = "cloudops"
          + "Region"      = "eastus"
          + "VNet"        = "main"
        }
    }

  # module.vnet["main"].azurerm_subnet.this["snet-app"] will be created
  + resource "azurerm_subnet" "this" {
      + address_prefixes                          = ["10.10.1.0/24"]
      + id                                        = (known after apply)
      + name                                      = "snet-app"
      + private_endpoint_network_policies         = "Enabled"
      + resource_group_name                       = "rg-cloudops-dev-eastus"
      + service_endpoints                         = ["Microsoft.Storage", "Microsoft.KeyVault"]
      + virtual_network_name                      = "vnet-main-cloudops-dev-eastus"
    }

  # module.vnet["main"].azurerm_subnet.this["snet-db"] will be created
  + resource "azurerm_subnet" "this" {
      + address_prefixes                          = ["10.10.2.0/24"]
      + id                                        = (known after apply)
      + name                                      = "snet-db"
      + private_endpoint_network_policies         = "Enabled"
      + resource_group_name                       = "rg-cloudops-dev-eastus"
      + service_endpoints                         = ["Microsoft.Storage"]
      + virtual_network_name                      = "vnet-main-cloudops-dev-eastus"
    }

  # module.vnet["main"].azurerm_network_security_group.this["snet-app"] will be created
  + resource "azurerm_network_security_group" "this" {
      + id                  = (known after apply)
      + location            = "eastus"
      + name                = "vnet-main-cloudops-dev-eastus-snet-app-nsg"
      + resource_group_name = "rg-cloudops-dev-eastus"
      + tags                = {
          + "CostCenter"  = "engineering"
          + "Environment" = "dev"
          + "ManagedBy"   = "terraform"
          + "Owner"       = "platform-team"
          + "Project"     = "cloudops"
          + "Region"      = "eastus"
          + "VNet"        = "main"
        }
    }

  # module.vnet["main"].azurerm_network_security_rule.this["snet-app-AllowHTTPS"] will be created
  + resource "azurerm_network_security_rule" "this" {
      + access                      = "Allow"
      + destination_address_prefix  = "*"
      + destination_port_range      = "443"
      + direction                   = "Inbound"
      + id                          = (known after apply)
      + name                        = "AllowHTTPS"
      + network_security_group_name = "vnet-main-cloudops-dev-eastus-snet-app-nsg"
      + priority                    = 100
      + protocol                    = "Tcp"
      + resource_group_name         = "rg-cloudops-dev-eastus"
      + source_address_prefix       = "Internet"
      + source_port_range           = "*"
    }

  # azurerm_key_vault.this will be created
  + resource "azurerm_key_vault" "this" {
      + id                            = (known after apply)
      + location                      = "eastus"
      + name                          = (known after apply)
      + public_network_access_enabled = true
      + purge_protection_enabled      = true
      + sku_name                      = "standard"
      + soft_delete_retention_days    = 30
      + tenant_id                     = (known after apply)
      + tags                          = {
          + "CostCenter"  = "engineering"
          + "Environment" = "dev"
          + "ManagedBy"   = "terraform"
          + "Owner"       = "platform-team"
          + "Project"     = "cloudops"
          + "Region"      = "eastus"
        }

      + network_acls {
          + bypass         = "AzureServices"
          + default_action = "Allow"
        }
    }

  # azurerm_disk_encryption_set.this will be created
  + resource "azurerm_disk_encryption_set" "this" {
      + id                  = (known after apply)
      + key_vault_key_id    = (known after apply)
      + location            = "eastus"
      + name                = "des-cloudops-dev-eastus"
      + resource_group_name = "rg-cloudops-dev-eastus"
      + tags                = {
          + "CostCenter"  = "engineering"
          + "Environment" = "dev"
          + "ManagedBy"   = "terraform"
          + "Owner"       = "platform-team"
          + "Project"     = "cloudops"
          + "Region"      = "eastus"
        }

      + identity {
          + type = "SystemAssigned"
        }
    }

  # module.storage["app"].azurerm_storage_account.this will be created
  + resource "azurerm_storage_account" "this" {
      + account_replication_type          = "ZRS"
      + account_tier                      = "Standard"
      + allow_nested_items_to_be_public   = false
      + https_traffic_only_enabled        = true
      + id                                = (known after apply)
      + infrastructure_encryption_enabled = true
      + location                          = "eastus"
      + min_tls_version                   = "TLS1_2"
      + name                              = (known after apply)
      + resource_group_name               = "rg-cloudops-dev-eastus"
      + shared_access_key_enabled         = false
      + tags                              = {
          + "CostCenter"     = "engineering"
          + "Environment"    = "dev"
          + "ManagedBy"      = "terraform"
          + "Owner"          = "platform-team"
          + "Project"        = "cloudops"
          + "Region"         = "eastus"
          + "StorageAccount" = "app"
        }

      + blob_properties {
          + change_feed_enabled      = true
          + versioning_enabled       = true

          + container_delete_retention_policy {
              + days = 7
            }

          + delete_retention_policy {
              + days = 7
            }
        }

      + network_rules {
          + bypass         = ["AzureServices"]
          + default_action = "Deny"
        }

      + identity {
          + type = "SystemAssigned"
        }
    }

  # module.vm["web"].azurerm_linux_virtual_machine.this will be created
  + resource "azurerm_linux_virtual_machine" "this" {
      + admin_username                  = "azureadmin"
      + disable_password_authentication = true
      + id                              = (known after apply)
      + location                        = "eastus"
      + name                            = "vm-web-cloudops-dev-eastus"
      + patch_mode                      = "AutomaticByPlatform"
      + resource_group_name             = "rg-cloudops-dev-eastus"
      + secure_boot_enabled             = true
      + size                            = "Standard_D2s_v3"
      + vtpm_enabled                    = true
      + zone                            = "1"
      + tags                            = {
          + "CostCenter"  = "engineering"
          + "Environment" = "dev"
          + "ManagedBy"   = "terraform"
          + "Owner"       = "platform-team"
          + "Project"     = "cloudops"
          + "Region"      = "eastus"
          + "VM"          = "web"
        }

      + os_disk {
          + caching                   = "ReadWrite"
          + disk_encryption_set_id    = (known after apply)
          + disk_size_gb              = 30
          + storage_account_type      = "Premium_LRS"
        }

      + source_image_reference {
          + offer     = "0001-com-ubuntu-server-jammy"
          + publisher = "Canonical"
          + sku       = "22_04-lts-gen2"
          + version   = "latest"
        }

      + identity {
          + type = "SystemAssigned"
        }
    }

  # azurerm_lb.this will be created
  + resource "azurerm_lb" "this" {
      + id                  = (known after apply)
      + location            = "eastus"
      + name                = "lb-cloudops-dev-eastus"
      + resource_group_name = "rg-cloudops-dev-eastus"
      + sku                 = "Standard"
      + tags                = {
          + "CostCenter"  = "engineering"
          + "Environment" = "dev"
          + "ManagedBy"   = "terraform"
          + "Owner"       = "platform-team"
          + "Project"     = "cloudops"
          + "Region"      = "eastus"
        }

      + frontend_ip_configuration {
          + name                          = "internal-frontend"
          + private_ip_address_allocation = "Dynamic"
          + zones                         = ["1", "2", "3"]
        }
    }

  # azurerm_recovery_services_vault.this will be created
  + resource "azurerm_recovery_services_vault" "this" {
      + id                  = (known after apply)
      + location            = "eastus"
      + name                = "rsv-cloudops-dev-eastus"
      + resource_group_name = "rg-cloudops-dev-eastus"
      + sku                 = "Standard"
      + storage_mode_type   = "LocallyRedundant"
      + tags                = {
          + "CostCenter"  = "engineering"
          + "Environment" = "dev"
          + "ManagedBy"   = "terraform"
          + "Owner"       = "platform-team"
          + "Project"     = "cloudops"
          + "Region"      = "eastus"
        }
    }

Plan: 25 to add, 0 to change, 0 to destroy.
```

> **To generate a live plan:** Clone this repo, authenticate with `az login`, then run:
> ```bash
> cd infrastructure
> terraform init -backend-config=environments/dev-eastus.backend.hcl
> terraform plan -var-file=environments/dev-eastus.tfvars -no-color
> ```
