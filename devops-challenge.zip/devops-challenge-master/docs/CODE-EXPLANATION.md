# Complete Code Explanation — Terraform & Pipeline

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Terraform Code — Infrastructure Layer](#terraform-code--infrastructure-layer)
3. [Terraform Code — VNet Module](#terraform-code--vnet-module)
4. [Terraform Code — VM Module](#terraform-code--vm-module)
5. [Terraform Code — Storage Module](#terraform-code--storage-module)
6. [Pipeline Code — CI Pipeline](#pipeline-code--ci-pipeline)
7. [Pipeline Code — Deploy Pipeline](#pipeline-code--deploy-pipeline)
8. [Pipeline Code — Module CI Pipeline](#pipeline-code--module-ci-pipeline)
9. [Design Decisions & Why](#design-decisions--why)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                        GitHub Repository                             │
│                                                                      │
│  modules/           ← Reusable building blocks (can be separate repo)│
│  ├── vnet/          ← Network module                                 │
│  ├── vm/            ← Compute module                                 │
│  └── storage/       ← Storage module                                 │
│                                                                      │
│  infrastructure/    ← Root module that composes everything            │
│  └── environments/  ← Per-environment variable files                 │
│      ├── dev-eastus.tfvars                                           │
│      ├── test-eastus2.tfvars                                         │
│      └── prod-westeurope.tfvars                                      │
│                                                                      │
│  .github/workflows/ ← CI/CD automation                               │
│      ├── terraform-ci.yml      (quality gate)                        │
│      ├── terraform-deploy.yml  (deploy lifecycle)                    │
│      └── promote.yml           (environment promotion)               │
└─────────────────────────────────────────────────────────────────────┘
                              │
                    Service Principal Auth
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        Azure Cloud                                    │
│                                                                      │
│  rg-cloudops-{env}-{region}                                          │
│  ├── VNet + Subnets + NSGs + Route Tables                            │
│  ├── Key Vault (CMK encryption keys + SSH secrets)                   │
│  ├── Disk Encryption Set (CMK for VM disks)                          │
│  ├── Linux VMs (Trusted Launch + zone-distributed)                   │
│  ├── Storage Accounts (CMK + deny-all + RBAC-only)                   │
│  ├── Load Balancer (Standard, zone-redundant)                        │
│  └── Recovery Services Vault (VM backups)                            │
│                                                                      │
│  rg-cloudops-tfstate (shared)                                        │
│  └── Storage Account (state backend with locking)                    │
└─────────────────────────────────────────────────────────────────────┘
```

**Design Philosophy:**
- **Modular** — Each Azure service type is its own module, independently testable and reusable
- **Scalable** — `for_each` maps let you scale by adding config, not code
- **Secure** — Zero-trust: deny-all networking, CMK encryption, RBAC-only, no shared keys
- **HA** — Availability Zones, zone-redundant storage/LB, daily backups with cross-region restore

---

## Terraform Code — Infrastructure Layer

### `infrastructure/versions.tf` — Provider Constraints

```hcl
terraform {
  required_version = ">= 1.5.0"
```
- **Why >= 1.5.0**: This is the minimum version that supports the native `terraform test` framework. We use this for module unit testing without third-party tools.

```hcl
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 3.70.0"
    }
```
- **Why azurerm >= 3.70.0**: Includes support for `private_endpoint_network_policies` (string type), `bgp_route_propagation_enabled`, Key Vault key rotation policies, and storage `storage_account_id` on containers.

```hcl
    random = {
      source  = "hashicorp/random"
      version = ">= 3.5.0"
    }
```
- **Why random provider**: Generates a 6-character suffix for globally unique names (Key Vault, Storage Account). Avoids naming collisions across subscriptions.

```hcl
    tls = {
      source  = "hashicorp/tls"
      version = ">= 4.0.0"
    }
```
- **Why tls provider**: Generates SSH key pairs for VMs within Terraform. No manual key management needed — keys are auto-stored in Key Vault.

```hcl
  backend "azurerm" {}
```
- **Why empty backend block**: The actual connection details (storage account, container, key) are injected via `-backend-config=environments/dev-eastus.backend.hcl`. This lets the same code point to different state files per environment without modification.
- **Advantage**: State isolation per environment — one bad `terraform destroy` in dev can't touch prod state.

---

### `infrastructure/providers.tf` — Provider Behaviour

```hcl
provider "azurerm" {
  features {
    resource_group {
      prevent_deletion_if_contains_resources = true
    }
```
- **Why**: Safety net — Terraform will refuse to destroy a resource group if it still has resources inside. Prevents accidental wipe of an entire environment.

```hcl
    virtual_machine {
      delete_os_disk_on_deletion    = true
      skip_shutdown_and_force_delete = false
    }
```
- **Why `delete_os_disk_on_deletion = true`**: When a VM is destroyed, its OS disk is cleaned up automatically. No orphaned disks accumulating cost.
- **Why `skip_shutdown_and_force_delete = false`**: VM is gracefully shut down before deletion. Prevents data corruption on data disks.

---

### `infrastructure/main.tf` — Root Module (Line by Line)

#### Locals Block

```hcl
locals {
  name_prefix = "${var.project_name}-${var.environment}-${var.location}"
```
- **What**: Constructs a reusable naming prefix like `cloudops-dev-eastus`.
- **Why**: Every resource uses this prefix, so naming is consistent and immediately identifies the environment + region.
- **Advantage**: Single source of truth for naming. Change `var.location` → all resource names update automatically.

```hcl
  common_tags = {
    Environment = var.environment    # "dev", "test", "prod"
    Project     = var.project_name   # "cloudops"
    ManagedBy   = "terraform"        # identifies IaC-managed resources
    CostCenter  = var.cost_center    # billing attribution
    Owner       = var.owner          # team accountability
    Region      = var.location       # region visibility in portal
  }
}
```
- **What**: A tag map applied to every single resource.
- **Why**: Tags enable cost tracking, ownership identification, automation (e.g., auto-shutdown scripts targeting `Environment=dev`), and compliance auditing.
- **Advantage**: Defined once, used everywhere via `tags = local.common_tags`. Adding a new tag = one-line change, all resources inherit it.

#### Resource Group

```hcl
resource "azurerm_resource_group" "this" {
  name     = "rg-${local.name_prefix}"
  location = var.location
  tags     = local.common_tags
}
```
- **What**: Creates a Resource Group — the logical container for all environment resources.
- **Why Resource Groups (not Subscriptions)**: RGs provide sufficient isolation for this challenge. They allow per-env RBAC, cost visibility via tags, and work within a single free-tier subscription. Subscriptions would be used at enterprise scale for hard billing boundaries.
- **Naming**: `rg-cloudops-dev-eastus` — type prefix + project + env + region.

#### Random Suffix

```hcl
resource "random_string" "suffix" {
  length  = 6
  special = false
  upper   = false
}
```
- **What**: Generates a random 6-char string like `a1b2c3`.
- **Why**: Azure Key Vault and Storage Account names must be globally unique. The suffix prevents collisions when multiple people deploy the same code.
- **Advantage**: Idempotent — once generated, the value is stored in state and never changes.

#### Data Source

```hcl
data "azurerm_client_config" "current" {}
```
- **What**: Retrieves the current deployer's identity (tenant_id, object_id, subscription_id).
- **Why**: Used to grant the deployer (Service Principal) access to Key Vault. Without this, the deployer couldn't create encryption keys.
- **Advantage**: No hardcoded IDs — works with any Service Principal that runs the pipeline.

#### VNet Module

```hcl
module "vnet" {
  source   = "../modules/vnet"
  for_each = var.vnets
```
- **What**: Creates one VNet per key in the `vnets` map variable.
- **Why `for_each`**: Scalability — in dev you have 1 VNet (`main`), in prod you have 2 (`app` + `data`). No code duplication — just add keys to tfvars.

```hcl
  name                = "vnet-${each.key}-${local.name_prefix}"
```
- **What**: Each VNet gets a unique name like `vnet-main-cloudops-dev-eastus`.
- **Why**: The name tells you: resource type (`vnet`), logical name (`main`), project, environment, and region.

```hcl
  tags = merge(local.common_tags, { VNet = each.key })
```
- **What**: Common tags plus a resource-specific label identifying which VNet this is.
- **Why**: If you have multiple VNets, the `VNet` tag differentiates them in cost reports.

#### Key Vault

```hcl
resource "azurerm_key_vault" "this" {
  name                          = "kv-${var.project_name}-${var.environment}-${random_string.suffix.result}"
```
- **Why random suffix**: Key Vault names are globally unique (DNS-based). Without suffix, two people deploying the same code would collide.

```hcl
  purge_protection_enabled      = true
  soft_delete_retention_days    = 30
```
- **Why purge protection**: Once enabled, deleted keys/secrets CANNOT be permanently removed for 30 days. This prevents ransomware or malicious actors from destroying encryption keys and making your data unrecoverable.
- **Advantage**: Even if the Key Vault is deleted, the keys are recoverable for 30 days.

```hcl
  public_network_access_enabled = var.environment == "prod" ? false : true
```
- **Why conditional**: Dev needs public access for developer laptops. Prod locks down to private network only.
- **Advantage**: Same code, different security posture per environment.

```hcl
  network_acls {
    default_action = var.environment == "prod" ? "Deny" : "Allow"
    bypass         = "AzureServices"
    virtual_network_subnet_ids = flatten([
      for vnet_key, vnet in module.vnet : [
        for subnet_key, subnet_id in vnet.subnet_ids : subnet_id
      ]
    ])
  }
```
- **What**: Firewall rules — in prod, only traffic from known subnets is allowed. `AzureServices` bypass lets Azure backup, monitoring, etc. still reach the vault.
- **Why `flatten` + nested loop**: Dynamically collects ALL subnet IDs from ALL VNets. As you add VNets/subnets, the firewall rules update automatically.

```hcl
  lifecycle {
    prevent_destroy = true
  }
```
- **Why**: Terraform will refuse to destroy this resource. Protects encryption keys from accidental `terraform destroy`.
- **Advantage**: Defence against human error. You must explicitly remove this lifecycle rule before destroying.

#### Management Lock

```hcl
resource "azurerm_management_lock" "kv_lock" {
  lock_level = "CanNotDelete"
}
```
- **What**: ARM-level deletion lock, independent of Terraform state.
- **Why**: Even if someone bypasses Terraform (Azure Portal, CLI), the Key Vault cannot be deleted.
- **Advantage**: Two layers of protection — Terraform's `prevent_destroy` + Azure's native lock.

#### Key Vault Key with Rotation

```hcl
resource "azurerm_key_vault_key" "disk_encryption" {
  key_type = "RSA"
  key_size = 4096
  key_opts = ["decrypt", "encrypt", "wrapKey", "unwrapKey"]
```
- **What**: Creates a 4096-bit RSA encryption key for VM disk encryption.
- **Why RSA-4096**: Industry standard for data-at-rest encryption. 4096 bits provides security margin beyond 2030.
- **Why these key_opts**: `wrapKey`/`unwrapKey` is what Disk Encryption Sets use to encrypt/decrypt the data encryption key (envelope encryption).

```hcl
  rotation_policy {
    automatic {
      time_before_expiry = "P30D"
    }
    expire_after         = "P365D"
    notify_before_expiry = "P29D"
  }
```
- **What**: Key automatically rotates 30 days before its 1-year expiry. Notifications sent at 29 days.
- **Why**: Compliance requirement (NIST, ISO 27001) — encryption keys must be rotated regularly. Manual rotation is error-prone.
- **Advantage**: Zero human intervention for key rotation. Azure handles re-encryption of data with the new key version.

#### Disk Encryption Set

```hcl
resource "azurerm_disk_encryption_set" "this" {
  key_vault_key_id = azurerm_key_vault_key.disk_encryption.id
  identity {
    type = "SystemAssigned"
  }
}
```
- **What**: A DES is the bridge between Key Vault keys and VM disks. Azure uses this to encrypt all VM disks with your customer-managed key (CMK).
- **Why SystemAssigned identity**: The DES gets its own managed identity — no shared credentials. The identity is granted RBAC access to the Key Vault.
- **Advantage over platform-managed encryption**: You control the key lifecycle. You can revoke the key to make data unreadable (crypto-shredding for compliance).

```hcl
resource "azurerm_role_assignment" "des_kv_access" {
  role_definition_name = "Key Vault Crypto Service Encryption User"
  principal_id         = azurerm_disk_encryption_set.this.identity[0].principal_id
}
```
- **What**: Grants the DES's identity permission to use the encryption key.
- **Why RBAC (not access policies)**: RBAC is the modern approach — granular, auditable, works with Azure AD Conditional Access.

#### Storage Module

```hcl
module "storage" {
  for_each = var.storage_accounts
  name = "st${var.project_name}${each.key}${var.environment}${random_string.suffix.result}"
```
- **What**: Creates storage accounts from a map. Name follows Azure's 3-24 lowercase alphanumeric requirement.
- **Why for_each**: Dev has 1 storage account, prod has 2 (app + backup). Scale via config.

```hcl
  allowed_subnet_ids = [
    for ref in each.value.allowed_subnet_ids_keys :
    module.vnet[ref.vnet_key].subnet_ids[ref.subnet_key]
  ]
```
- **What**: Resolves VNet/subnet references from tfvars to actual subnet IDs.
- **Why indirect reference via keys**: Avoids hardcoding subnet IDs. The tfvars just says "allow from main/snet-app" — Terraform resolves the actual ID.

```hcl
  soft_delete_retention_days           = var.environment == "prod" ? 30 : 7
  container_soft_delete_retention_days = var.environment == "prod" ? 30 : 7
```
- **Why conditional**: Prod needs longer retention for compliance (30 days to recover accidentally deleted data). Dev uses 7 days to save cost.

#### Recovery Services Vault

```hcl
resource "azurerm_recovery_services_vault" "this" {
  storage_mode_type = var.environment == "prod" ? "ZoneRedundant" : "LocallyRedundant"
```
- **What**: Backup vault for VM snapshots.
- **Why ZoneRedundant in prod**: Backup data is replicated across 3 availability zones. If an entire zone goes down, backups are still accessible.
- **Why LocallyRedundant in dev**: Cheaper, sufficient for non-production.

```hcl
  cross_region_restore_enabled = var.environment == "prod" ? true : false
  immutability                 = var.environment == "prod" ? "Unlocked" : null
```
- **Why cross-region restore**: Prod can restore VMs to a secondary region if the primary region has an outage (disaster recovery).
- **Why immutability**: Once set, backup data cannot be deleted before its retention expires. Protects against ransomware deleting backups.

#### Backup Policy

```hcl
  backup {
    frequency = "Daily"
    time      = "02:00"
  }
  retention_daily {
    count = var.environment == "prod" ? 30 : 7
  }
  retention_weekly {
    count    = var.environment == "prod" ? 12 : 4
    weekdays = ["Sunday"]
  }
```
- **What**: Daily backups at 2 AM (off-peak). Keep 30 daily + 12 weekly restore points in prod.
- **Why 2 AM**: Minimizes impact on running workloads during snapshot.
- **Why weekly retention**: Allows point-in-time recovery to any day in the last month, or any Sunday in the last 3 months.

#### VM Module

```hcl
module "vm" {
  for_each = var.vms
  subnet_id = module.vnet[each.value.vnet_key].subnet_ids[each.value.subnet_key]
```
- **What**: Each VM references its VNet/subnet by logical key from tfvars.
- **Why**: Decoupled — you can move a VM to a different subnet by changing one tfvars value, not restructuring code.

```hcl
  disk_encryption_set_id = azurerm_disk_encryption_set.this.id
  depends_on = [azurerm_role_assignment.des_kv_access]
```
- **Why depends_on**: The DES must have Key Vault RBAC access BEFORE a VM tries to use it for disk encryption. Without this, deployment would race-condition and fail.

#### SSH Key Storage

```hcl
resource "azurerm_key_vault_secret" "vm_ssh_key" {
  for_each = module.vm
  name     = "vm-ssh-key-${each.key}-${var.environment}"
  value    = each.value.ssh_private_key
}
```
- **What**: Stores each VM's SSH private key in Key Vault.
- **Why**: SSH keys should never be in state files or CI logs. Key Vault provides audited, access-controlled secret storage.
- **Advantage**: Operations team retrieves keys via `az keyvault secret show` — no need to share files.

#### Load Balancer

```hcl
resource "azurerm_lb" "this" {
  sku = "Standard"
  frontend_ip_configuration {
    zones = ["1", "2", "3"]
  }
}
```
- **What**: Internal Standard Load Balancer spanning all 3 availability zones.
- **Why Standard SKU**: Required for availability zone support. Basic SKU cannot be zone-redundant.
- **Why zones 1,2,3**: If any zone fails, the LB frontend IP still works from surviving zones.

```hcl
resource "azurerm_network_interface_backend_address_pool_association" "vm" {
  for_each = module.vm
}
```
- **What**: Automatically adds ALL VMs to the LB backend pool.
- **Why for_each over module.vm**: As you add VMs in tfvars, they're automatically load-balanced. No manual pool management.

```hcl
resource "azurerm_lb_probe" "http" { port = 80 }
resource "azurerm_lb_probe" "https" { port = 443 }
```
- **What**: Separate health probes for each protocol.
- **Why separate**: If HTTPS is down but HTTP works (cert issue), the LB correctly routes each protocol based on its actual health.

```hcl
  disable_outbound_snat = true
```
- **Why**: Best practice — prevents the LB from implicitly providing outbound internet access. Forces explicit outbound NAT or Azure Firewall configuration. Security improvement.

---

## Terraform Code — VNet Module

### `modules/vnet/main.tf`

```hcl
resource "azurerm_virtual_network" "this" {
  dns_servers = length(var.dns_servers) > 0 ? var.dns_servers : null
```
- **What**: Custom DNS is optional. When null, Azure's default DNS (168.63.129.16) is used.
- **Why optional**: Some environments need custom DNS (e.g., on-prem resolution). Others don't. Module handles both.

```hcl
  dynamic "ddos_protection_plan" {
    for_each = var.enable_ddos_protection ? [1] : []
    content {
      id     = var.create_ddos_protection_plan ? azurerm_network_ddos_protection_plan.this[0].id : var.ddos_protection_plan_id
      enable = true
    }
  }
```
- **What**: Optional DDoS protection — can create a new plan OR reference an existing one.
- **Why dynamic block**: DDoS costs ~$2,944/month. Should only be enabled in prod. Dynamic block means the resource isn't created at all when disabled (not just disabled).
- **Why both options**: Multiple VNets in the same region should share ONE DDoS plan (cost optimization). The first VNet creates it, others reference it.

```hcl
resource "azurerm_subnet" "this" {
  for_each = var.subnets
  service_endpoints = each.value.service_endpoints
  private_endpoint_network_policies = each.value.private_endpoint_network_policies_enabled ? "Enabled" : "Disabled"
```
- **What**: Subnets are created from a map — each with configurable service endpoints and private endpoint policies.
- **Why service_endpoints**: Allow Storage/KeyVault to be accessed over the Azure backbone (not public internet) from specific subnets. Security + performance.
- **Why private_endpoint_network_policies**: Controls whether NSG/UDR rules apply to private endpoints in this subnet. Required for advanced micro-segmentation.

```hcl
  dynamic "delegation" {
    for_each = each.value.delegation != null ? [each.value.delegation] : []
```
- **What**: Optional subnet delegation (e.g., to Azure App Service, ACI, PostgreSQL Flexible Server).
- **Why**: Some Azure services require a dedicated (delegated) subnet. Module supports this without code changes.

#### NSG Pattern

```hcl
resource "azurerm_network_security_group" "this" {
  for_each = var.nsg_rules
  name     = "${var.name}-${each.key}-nsg"
}
```
- **What**: Creates one NSG per subnet that has rules defined.
- **Why per-subnet NSGs**: Micro-segmentation — each subnet has its own security boundary. App subnet allows HTTPS, DB subnet denies internet entirely.

```hcl
resource "azurerm_network_security_rule" "this" {
  for_each = { for item in flatten([...]) : item.key => item }
```
- **What**: Flattens the nested map (subnet → list of rules) into a single flat map for `for_each`.
- **Why this pattern**: Terraform requires a flat map for `for_each`. The flatten + comprehension transforms `{ subnet: [rule1, rule2] }` into `{ "subnet-rule1": {...}, "subnet-rule2": {...} }`.
- **Advantage**: Unlimited rules per subnet, all managed declaratively.

#### Route Tables

```hcl
resource "azurerm_route_table" "this" {
  for_each = var.route_tables
  bgp_route_propagation_enabled = !each.value.disable_bgp_route_propagation
}
```
- **What**: Custom routes per subnet (e.g., force all traffic through a firewall).
- **Why disable BGP propagation**: When using a hub-spoke topology with Azure Firewall, you want to control routes explicitly, not have them injected by BGP.

---

## Terraform Code — VM Module

### `modules/vm/main.tf`

```hcl
resource "tls_private_key" "this" {
  algorithm = "RSA"
  rsa_bits  = 4096
}
```
- **What**: Generates a unique SSH key pair per VM at creation time.
- **Why**: Each VM has its own key — compromising one key doesn't compromise all VMs. 4096-bit RSA is NIST-approved through 2030+.
- **Advantage**: No manual key generation or distribution. Keys are stored in Key Vault automatically.

```hcl
resource "azurerm_network_interface" "this" {
  accelerated_networking_enabled = var.enable_accelerated_networking
}
```
- **What**: NIC with SR-IOV hardware offload.
- **Why**: Accelerated Networking reduces latency by ~50% and increases throughput to 25Gbps. No extra cost on supported VM sizes.

```hcl
resource "azurerm_linux_virtual_machine" "this" {
  disable_password_authentication = true
  zone = var.availability_zone
  secure_boot_enabled = var.enable_secure_boot
  vtpm_enabled        = var.enable_vtpm
```
- **Why no password auth**: SSH keys only — eliminates brute-force password attacks entirely.
- **Why zone placement**: Each VM is pinned to a specific zone. Combined with the zone-redundant LB, this provides HA — if zone 1 fails, VMs in zones 2+3 continue serving.
- **Why Trusted Launch (SecureBoot + vTPM)**: Prevents rootkits and bootkits from modifying the boot chain. vTPM provides measured boot attestation — you can verify the VM hasn't been tampered with.

```hcl
  os_disk {
    disk_encryption_set_id = var.disk_encryption_set_id
  }
```
- **Why CMK on OS disk**: Customer-managed encryption means YOU control the key. Revoking the key makes the disk unreadable — required for data sovereignty compliance (GDPR, HIPAA).

```hcl
  identity {
    type = "SystemAssigned"
  }
```
- **What**: VM gets its own Azure AD identity (managed by Azure).
- **Why**: The VM can authenticate to other Azure services (Key Vault, Storage, etc.) WITHOUT storing any credentials on the VM. Zero secrets on disk.

```hcl
  patch_mode = var.patch_mode  # "AutomaticByPlatform"
```
- **What**: Azure manages OS patching automatically with maintenance windows.
- **Why**: Unpatched VMs are the #1 attack vector. Automatic patching ensures security updates are applied without human delay.

```hcl
resource "azurerm_managed_disk" "this" {
  zone = var.availability_zone
  disk_encryption_set_id = var.disk_encryption_set_id
```
- **Why zone-aligned data disks**: Data disks MUST be in the same zone as the VM. Cross-zone disk attachment is not supported in Azure.
- **Why CMK on data disks too**: Consistent encryption posture — all data at rest uses your key.

```hcl
resource "azurerm_virtual_machine_extension" "azure_monitor" {
  count = var.enable_monitoring ? 1 : 0
  type  = "AzureMonitorLinuxAgent"
  automatic_upgrade_enabled = true
```
- **What**: Installs Azure Monitor Agent for metrics, logs, and diagnostics.
- **Why conditional**: Dev might not need full monitoring (cost saving). Prod always enables it.
- **Why auto-upgrade**: Agent stays current without manual intervention — important for security patches in the agent itself.

```hcl
resource "azurerm_backup_protected_vm" "this" {
  count = var.enable_backup ? 1 : 0
```
- **What**: Registers the VM with the Recovery Services Vault for daily backups.
- **Why conditional**: Dev VMs are ephemeral — backing them up wastes money. Prod VMs contain state that must be recoverable.

---

## Terraform Code — Storage Module

### `modules/storage/main.tf`

```hcl
  min_tls_version                 = "TLS1_2"
  allow_nested_items_to_be_public = false
  shared_access_key_enabled       = false
  https_traffic_only_enabled      = true
```
- **Why TLS 1.2**: Older versions (1.0, 1.1) have known vulnerabilities. 1.2 is the minimum secure version.
- **Why no public blobs**: Prevents accidental data leaks. Even if a container is set to "blob" access level, the account-level setting overrides it.
- **Why shared keys disabled**: Forces ALL access through Azure AD RBAC. No SAS tokens or account keys that could be leaked.
- **Why HTTPS only**: Prevents data interception in transit.

```hcl
  infrastructure_encryption_enabled = var.enable_infrastructure_encryption
```
- **What**: Double encryption — data is encrypted at the storage layer AND at the infrastructure (hardware) layer.
- **Why**: Defence in depth — even if one encryption layer is compromised, data remains protected. Required for FedRAMP High and some financial regulations.

```hcl
  blob_properties {
    versioning_enabled       = var.enable_versioning
    change_feed_enabled      = var.enable_change_feed
    delete_retention_policy { days = var.soft_delete_retention_days }
    container_delete_retention_policy { days = var.container_soft_delete_retention_days }
  }
```
- **Why versioning**: Every blob modification creates a new version. Enables point-in-time recovery and protects against accidental overwrites.
- **Why change feed**: Provides an ordered, guaranteed, durable log of all blob changes. Enables audit trails and event-driven processing.
- **Why soft delete**: Deleted blobs/containers are recoverable for N days. Protects against accidental or malicious deletion.

```hcl
  network_rules {
    default_action             = "Deny"
    virtual_network_subnet_ids = var.allowed_subnet_ids
    bypass                     = ["AzureServices", "Logging", "Metrics"]
  }
```
- **What**: Firewall denies ALL traffic by default, only allows specified subnets.
- **Why deny-all**: Zero-trust networking — only explicitly allowed networks can reach the storage account.
- **Why bypass AzureServices**: Allows Azure Backup, Monitor, and other platform services to still function.

```hcl
  identity {
    type = "SystemAssigned"
  }
```
- **Why**: Storage account gets its own managed identity — used to authenticate to Key Vault for CMK encryption. No secrets stored anywhere.

#### Lifecycle Management

```hcl
resource "azurerm_storage_management_policy" "this" {
  dynamic "rule" {
    actions {
      base_blob {
        tier_to_cool_after_days_since_last_access_time_greater_than    = rule.value.tier_to_cool_after_days
        tier_to_archive_after_days_since_last_access_time_greater_than = rule.value.tier_to_archive_after_days
        delete_after_days_since_last_access_time_greater_than          = rule.value.delete_after_days
      }
```
- **What**: Auto-tiers blobs based on access patterns — hot → cool → archive → delete.
- **Why**: Cost optimization at scale. Cool tier is 50% cheaper, archive is 90% cheaper. Infrequently accessed data automatically moves to cheaper tiers.
- **Advantage**: Configured entirely via tfvars — operations team sets the rules without touching code.

#### Customer-Managed Key

```hcl
resource "azurerm_storage_account_customer_managed_key" "this" {
  count = var.encryption_key_vault_key_id != null ? 1 : 0
  key_vault_key_id = var.encryption_key_vault_key_id
}
```
- **What**: Replaces Microsoft-managed encryption key with your own Key Vault key.
- **Why**: Full control over encryption lifecycle. Key rotation, revocation (crypto-shredding), and audit are under your control.
- **Why conditional**: Allows the module to work without CMK (useful for testing or non-sensitive workloads).

---

## Pipeline Code — CI Pipeline

### `.github/workflows/terraform-ci.yml`

```yaml
on:
  pull_request:
    branches: [main, develop]
    paths: ["modules/**", "infrastructure/**", ".github/workflows/**"]
  push:
    branches: [main, develop]
    paths: ["modules/**", "infrastructure/**"]
```
- **What**: Triggers on PRs targeting main/develop AND on merges to main/develop.
- **Why paths filter**: Only runs when Terraform or workflow files change. Docs-only changes don't waste CI minutes.
- **Why both triggers**: PR = quality gate before merge. Push = validation after merge (catches merge-conflict issues).

```yaml
permissions:
  contents: read
  pull-requests: write
  security-events: write
```
- **Why minimal permissions**: Principle of least privilege. Only grants what's needed: read code, comment on PRs, upload SARIF security results.

```yaml
env:
  TF_VERSION: "1.7.0"
  TFLINT_VERSION: "v0.50.0"
```
- **Why pinned versions**: Reproducibility — all jobs use identical tool versions. Prevents "works on my machine" issues.

#### Format Job

```yaml
- name: Terraform Format Check
  run: terraform fmt -check -recursive -diff
```
- **What**: Verifies all `.tf` files follow standard formatting.
- **Why**: Consistent code style across the team. `-diff` shows exactly what would change, making it easy to fix.
- **Advantage**: No style debates in code review — the formatter is the authority.

#### Validate Job

```yaml
strategy:
  matrix:
    directory: [modules/vnet, modules/vm, modules/storage, infrastructure]
steps:
  - run: terraform init -backend=false
  - run: terraform validate
```
- **What**: Runs `terraform validate` on each module + infrastructure independently.
- **Why matrix**: Parallel execution — all 4 validations run simultaneously, fail independently.
- **Why `-backend=false`**: No Azure credentials needed for validation. It only checks HCL syntax and provider schema.

#### Lint Job

```yaml
- name: Run TFLint
  run: tflint --recursive
```
- **What**: Static analysis that catches issues `terraform validate` misses — deprecated attributes, invalid VM sizes, naming violations.
- **Why**: Catches provider-specific issues before deployment. Example: using a VM size not available in the target region.

#### Security Job

```yaml
- name: tfsec
  uses: aquasecurity/tfsec-action@v1.0.3
  with:
    additional_args: "--minimum-severity MEDIUM"
    soft_fail: true
```
- **What**: Scans Terraform for security misconfigurations (unencrypted storage, public access, missing network rules).
- **Why MEDIUM threshold**: Ignores LOW (informational) — focuses on actionable findings.
- **Why soft_fail**: Doesn't block the pipeline — allows team to review findings and address them. Hard-fail would block ALL PRs on any new advisory.

```yaml
- name: Checkov
  uses: bridgecrewio/checkov-action@v12
  with:
    output_format: sarif
```
- **What**: Second scanner (different rule engine) — catches issues tfsec might miss.
- **Why SARIF output**: Integrates with GitHub's Security tab — findings appear alongside code, with fix recommendations.
- **Advantage**: Two independent scanners reduce false negatives.

#### Test Job

```yaml
needs: [validate]
steps:
  - run: terraform init -backend=false
  - run: terraform test -no-color
```
- **What**: Runs native Terraform test framework (`.tftest.hcl` files).
- **Why `needs: [validate]`**: Tests only run if validation passes — saves runner time on broken code.
- **What the tests verify**: Resource names, security settings (TLS version, shared keys disabled, secure boot), correct zone placement, tag application.
- **Advantage**: Tests run at plan level (no Azure credentials needed) — fast, free, always available in CI.

---

## Pipeline Code — Deploy Pipeline

### `.github/workflows/terraform-deploy.yml`

```yaml
on:
  workflow_dispatch:
    inputs:
      environment:
        type: choice
        options: [dev-eastus, test-eastus2, prod-westeurope]
      action:
        type: choice
        options: [plan, apply, destroy]
  push:
    branches: [main]
```
- **What**: Two triggers — manual dispatch (choose env + action) OR automatic on push to main.
- **Why manual dispatch**: Operators can plan/apply/destroy any environment on-demand.
- **Why push trigger**: Merge to main = auto-deploy to dev. Continuous deployment for the lowest environment.

```yaml
concurrency:
  group: terraform-${{ github.event.inputs.environment || 'dev-eastus' }}
  cancel-in-progress: false
```
- **What**: Only one deployment per environment can run at a time.
- **Why**: Prevents state file conflicts. Two concurrent applies would corrupt state.
- **Why `cancel-in-progress: false`**: We DON'T cancel running deployments — that could leave infrastructure in a partial state.

#### Setup Job

```yaml
outputs:
  environments: ${{ steps.set-env.outputs.environments }}
  action: ${{ steps.set-action.outputs.action }}
```
- **What**: Determines which environment(s) to deploy and what action to perform.
- **Why separate job**: Allows the matrix strategy in downstream jobs to be dynamic based on input.

#### Plan Job

```yaml
environment: ${{ matrix.environment }}-plan
env:
  ARM_CLIENT_ID: ${{ secrets.AZURE_CLIENT_ID }}
  ARM_CLIENT_SECRET: ${{ secrets.AZURE_CLIENT_SECRET }}
  ARM_SUBSCRIPTION_ID: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
  ARM_TENANT_ID: ${{ secrets.AZURE_TENANT_ID }}
```
- **What**: Uses GitHub Environment secrets for Azure Service Principal auth.
- **Why environment-scoped secrets**: Each environment can have its own SPN with scoped permissions. Dev SPN can't touch prod resources.
- **Why `{env}-plan` environment**: Separate environment without protection rules — planning doesn't need approval.

```yaml
- name: Terraform Plan
  run: |
    terraform plan \
      -var-file=environments/${{ matrix.environment }}.tfvars \
      -out=${{ matrix.environment }}.tfplan \
      -detailed-exitcode \
      -input=false \
      2>&1 | tee plan_output.txt
  continue-on-error: true
```
- **Why `-out`**: Saves the exact plan to a binary file. What was reviewed = what gets applied. No drift between plan and apply.
- **Why `-detailed-exitcode`**: Returns exit code 2 if changes are detected (vs 0 for no changes). Enables conditional logic.
- **Why `-input=false`**: Prevents the plan from prompting for missing variables — fails fast instead of hanging.
- **Why `tee`**: Captures output to file (for PR comment) while still showing in CI logs.
- **Why `continue-on-error`**: Allows subsequent steps (upload, comment) to run even if plan has changes (exit code 2).

```yaml
- name: Upload Plan
  uses: actions/upload-artifact@v4
  with:
    retention-days: 5
```
- **What**: Stores the plan binary as a pipeline artifact.
- **Why**: The apply job downloads this exact artifact — ensures plan-to-apply consistency.
- **Why 5 days retention**: Plans become stale quickly (infrastructure changes). 5 days is sufficient for review cycles.

```yaml
- name: Comment Plan on PR
  if: github.event_name == 'pull_request'
  uses: actions/github-script@v7
```
- **What**: Posts the terraform plan output as a PR comment.
- **Why**: Reviewers see infrastructure changes directly in the PR — no need to open the Actions log. Makes code review more effective.

#### Apply Job

```yaml
environment: ${{ matrix.environment }}
```
- **What**: References the GitHub Environment WITH protection rules.
- **Why**: `test` and `prod` environments have required reviewers. The pipeline pauses until a human approves.
- **Advantage**: Separation of duties — developer creates the plan, senior engineer approves the apply.

```yaml
- name: Download Plan
  uses: actions/download-artifact@v4
- name: Terraform Apply
  run: terraform apply -auto-approve -input=false ${{ matrix.environment }}.tfplan
```
- **What**: Downloads the previously-uploaded plan and applies it.
- **Why `-auto-approve` is safe here**: The plan was already reviewed (PR + approval). Applying a saved plan is deterministic — it won't make changes beyond what was shown.
- **Advantage**: What was planned = what is applied. No surprises.

#### Destroy Job

```yaml
environment: ${{ matrix.environment }}-destroy
```
- **What**: Destroy has its own environment with separate approvers.
- **Why**: Destroying infrastructure is irreversible. Requires additional approval from a different set of people than regular deployment.

---

## Pipeline Code — Module CI Pipeline

### `modules/.github/workflows/module-ci.yml`

This pipeline is designed to be **self-contained** — when you copy the `modules/` folder to a separate repository, this pipeline works without modification.

```yaml
on:
  pull_request:
    paths: ["**/*.tf", "**/*.tftest.hcl"]
  push:
    branches: [main, develop]
    paths: ["**/*.tf", "**/*.tftest.hcl"]
```
- **What**: Triggers on any Terraform file change.
- **Why `**/*.tftest.hcl`**: Also triggers when test files change — ensures tests still pass.

#### Release Lifecycle for Modules:

```
Feature Branch → PR → [Format + Validate + Lint + Test + Security] → Merge → [Same checks on main]
```

1. **Developer creates feature branch** — makes module changes
2. **Opens PR** — CI triggers automatically
3. **Format**: Enforces style consistency
4. **Validate**: Ensures HCL is syntactically correct
5. **Lint**: Catches provider-specific issues (tflint)
6. **Test**: Runs `terraform test` — verifies module behaviour against assertions
7. **Security**: tfsec + checkov find vulnerabilities
8. **Summary gate**: All must pass before merge is allowed
9. **Merge to main** — pipeline runs again to verify the merged result

```yaml
  summary:
    needs: [format, validate, lint, test, security]
    if: always()
    steps:
      - name: Check results
        run: |
          if [ "${{ needs.test.result }}" == "failure" ]; then
            exit 1
          fi
```
- **What**: A final gate job that aggregates all results.
- **Why**: GitHub branch protection can require this single job to pass, instead of listing all individual jobs.
- **Why `if: always()`**: Runs even if upstream jobs fail — ensures the failure is properly reported.

---

## Design Decisions & Why

### Why Modules Instead of Inline Resources?

| Without Modules | With Modules |
|----------------|-------------|
| One huge `main.tf` | Logical separation by service type |
| Can't reuse VNet config across repos | `source = "../modules/vnet"` or `source = "git::..."` |
| Testing requires full infra | Test each module independently |
| Team steps on each other | Different teams own different modules |

### Why `for_each` Maps Instead of `count`?

| `count` | `for_each` |
|---------|-----------|
| Resources identified by index [0], [1] | Identified by key ["web"], ["api"] |
| Removing item [0] renumbers everything → destroys/recreates | Removing key "web" only affects that one resource |
| No way to target specific instance | `terraform apply -target=module.vm["web"]` |

### Why Service Principal (Not OIDC)?

| Service Principal | OIDC |
|-------------------|------|
| Works with GitHub Enterprise Server | Requires GitHub.com or GHES 3.5+ |
| Simple JSON credential | Requires federated identity setup in Azure AD |
| Rotate secret periodically | No secret to rotate (advantage) |
| Battle-tested in most orgs | Newer, less tooling support |

We chose SPN for broad compatibility. OIDC would be preferred for new projects on GitHub.com.

### Why Separate State Per Environment?

```
tfstate/
├── dev-eastus/terraform.tfstate
├── test-eastus2/terraform.tfstate
└── prod-westeurope/terraform.tfstate
```

- **Blast radius**: A bad `terraform apply` only affects one environment
- **Permissions**: Dev team can plan/apply dev without prod state access
- **Speed**: Smaller state = faster plan/apply
- **Locking**: Environment-level locks don't block other environments

### Why These Specific Resources?

| Resource | Why Chosen |
|----------|-----------|
| **VNet** | Required by the challenge — core networking |
| **VM** | Required by the challenge — demonstrates compute patterns |
| **Storage Account** | Challenge suggests "Blob" — demonstrates data patterns |
| **Key Vault** | Needed for CMK encryption + secret management |
| **Load Balancer** | Demonstrates HA pattern — distributes traffic across VMs |
| **Recovery Vault** | Demonstrates backup/DR — production-readiness |
| **Disk Encryption Set** | Demonstrates security — CMK for all disks |

---

## Summary

This implementation goes beyond the challenge requirements by demonstrating:

1. **Clean code** — Modules, locals, consistent naming, no duplication
2. **Security** — Zero-trust networking, CMK, RBAC-only, Trusted Launch, no shared keys
3. **HA** — Availability Zones, zone-redundant LB/Storage, cross-region backups
4. **Scalability** — `for_each` maps: scale via config, not code
5. **Automation** — Full CI/CD with quality gates, approval workflows, and security scanning
6. **Testing** — Native Terraform test framework with assertions on security invariants
7. **Documentation** — Automated via terraform-docs, comprehensive manual docs
