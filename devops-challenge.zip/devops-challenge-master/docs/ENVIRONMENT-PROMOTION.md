# Environment Promotion

## Promotion Path

```
dev → test → prod
```

Direct promotion from `dev` to `prod` is **blocked** by the pipeline.

## How It Works

1. Code changes are deployed to `dev` automatically on merge to `main`
2. After validation in `dev`, trigger promotion to `test` via workflow dispatch
3. After validation in `test`, trigger promotion to `prod` via workflow dispatch
4. `test` and `prod` require manual approval via GitHub Environment protection rules

## Triggering Promotion

1. Go to **Actions** → **Promote Environment**
2. Click **Run workflow**
3. Select source (`dev` or `test`) and target (`test` or `prod`)
4. Approve when prompted (for `test`/`prod` environments)

## What "Promotion" Means

Since all environments use the **same Terraform code** (from the current branch), promotion means:
- Running `terraform plan` with the **target environment's** tfvars
- Applying the plan after approval

The code is identical — only the configuration (variables) differs per environment.

## Safety Controls

| Control | Purpose |
|---------|---------|
| Path validation | Prevents skipping test (dev→prod blocked) |
| Environment protection | Manual approval for test/prod |
| Concurrency locks | One deploy per environment at a time |
| Plan artifact | Apply uses exact plan from plan step |
| Branch restrictions | Prod only deployable from main |
