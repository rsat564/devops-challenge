# Deployment Guide

## Prerequisites

1. Azure subscription with Owner/Contributor role
2. Azure CLI (`az`) installed
3. Terraform >= 1.5.0
4. GitHub repository with Actions enabled

## Step 1: Setup State Backend

```bash
# Authenticate to Azure
az login
az account set --subscription <your-subscription-id>

# Run setup script (one-time)
./scripts/setup-backend.sh    # Linux/macOS
.\scripts\setup-backend.ps1   # Windows
```

## Step 2: Create Azure Service Principal

Create a Service Principal (SPN) for GitHub Actions to authenticate with Azure. This is the equivalent of an **Azure DevOps Service Connection** — in GitHub, SPN credentials are stored as **GitHub Secrets** (repository or environment-scoped).

```bash
# Create Service Principal with Contributor role
az ad sp create-for-rbac \
  --name "spn-cloudops-github-terraform" \
  --role Contributor \
  --scopes /subscriptions/<subscription-id> \
  --sdk-auth

# Output will include: clientId, clientSecret, subscriptionId, tenantId
# Save these values — you'll store them as GitHub Secrets
```

For tighter security, create separate SPNs per environment:

```bash
for ENV in dev test prod; do
  az ad sp create-for-rbac \
    --name "spn-cloudops-github-${ENV}" \
    --role Contributor \
    --scopes /subscriptions/<subscription-id>/resourceGroups/rg-cloudops-${ENV} \
    --sdk-auth
done
```

## Step 3: Configure GitHub Secrets (Service Connection Equivalent)

In Azure DevOps, you create **Service Connections** to store SPN credentials. In GitHub, the equivalent is **GitHub Secrets** stored at the repository or environment level.

Navigate to: **Settings → Secrets and variables → Actions → New repository secret**

| Secret | Value | Description |
|--------|-------|-------------|
| `AZURE_CLIENT_ID` | Service Principal App/Client ID | SPN identity |
| `AZURE_CLIENT_SECRET` | Service Principal Password/Secret | SPN credential |
| `AZURE_SUBSCRIPTION_ID` | Target Azure Subscription ID | Deployment target |
| `AZURE_TENANT_ID` | Azure AD Tenant ID | Azure AD directory |

> **Per-environment secrets (recommended):** For isolation, create these secrets at the **environment level** instead of repository level. Go to Settings → Environments → select environment → Add secret. This ensures each environment uses its own SPN.

### Comparison: Azure DevOps vs GitHub

| Azure DevOps | GitHub Actions | Purpose |
|--------------|---------------|---------|
| Service Connection | GitHub Environment Secrets | Store SPN credentials |
| Service Connection (scope) | Environment protection rules | Control who can deploy where |
| Variable Groups | Repository/Environment Variables | Non-secret config |
| Approval Gates | Environment reviewers | Manual approval before deploy |

## Step 4: Configure GitHub Environments

Create environments in GitHub → Settings → Environments:

- `dev` — no protection rules
- `dev-plan` — no protection rules
- `test` — required reviewers
- `test-plan` — no protection rules
- `prod` — required reviewers + deployment branches (main only)
- `prod-plan` — no protection rules

## Step 5: Deploy

### Automated (push to main)
Push to `main` branch → automatically deploys to `dev`.

### Manual Deployment
Go to Actions → "Terraform Deploy" → Run workflow → Select environment & action.

### Promotion
Go to Actions → "Promote Environment" → Select source & target.

## Local Development

```bash
cd infrastructure
terraform init -backend-config=environments/dev-eastus.backend.hcl
terraform plan -var-file=environments/dev-eastus.tfvars
terraform apply -var-file=environments/dev-eastus.tfvars
```
