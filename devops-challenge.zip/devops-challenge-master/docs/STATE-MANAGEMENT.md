# State Management Guide

## Overview

This project uses **Azure Storage Account** as the Terraform remote backend with separate state files per environment.

## Architecture

```
stcloudopstfstate (Storage Account)
└── tfstate (Container)
    ├── dev/terraform.tfstate
    ├── test/terraform.tfstate
    └── prod/terraform.tfstate
```

## Initial Setup

Run the one-time setup script:

```bash
# Linux/macOS
chmod +x scripts/setup-backend.sh
./scripts/setup-backend.sh

# Windows
.\scripts\setup-backend.ps1
```

This creates:
- Resource group: `rg-cloudops-tfstate`
- Storage account: `stcloudopstfstate` (ZRS, versioning, soft-delete)
- Container: `tfstate`
- Delete lock on resource group

## Usage

Initialize Terraform for a specific environment:

```bash
cd infrastructure
terraform init -backend-config=environments/dev-eastus.backend.hcl
```

Switch environments (requires re-init):

```bash
terraform init -reconfigure -backend-config=environments/prod-westeurope.backend.hcl
```

## Best Practices for Large Teams

### 1. State Locking

Azure Blob storage provides native **lease-based locking**. Terraform automatically acquires a lease before writing state. No additional configuration needed.

### 2. RBAC Access Control

Use Azure RBAC instead of storage account keys:

| Role | Who | Purpose |
|------|-----|---------|
| Storage Blob Data Contributor | CI/CD Service Principal | Read/write state |
| Storage Blob Data Reader | Developers (read-only) | Plan without write |
| Storage Blob Data Owner | Platform team only | Break locks, recover |

```bash
# Grant CI/CD access
az role assignment create \
  --assignee <sp-object-id> \
  --role "Storage Blob Data Contributor" \
  --scope "/subscriptions/<sub>/resourceGroups/rg-cloudops-tfstate/providers/Microsoft.Storage/storageAccounts/stcloudopstfstate"
```

### 3. State File Per Environment

Never share state between environments. Each environment has:
- Separate state key (`dev-eastus/terraform.tfstate`, `test-eastus2/terraform.tfstate`, `prod-westeurope/terraform.tfstate`)
- Separate backend config file (`dev-eastus.backend.hcl`, `test-eastus2.backend.hcl`, `prod-westeurope.backend.hcl`)

### 4. State Versioning & Recovery

The storage account has **blob versioning** enabled:
- Every state change creates a new version
- Soft-delete retention: 30 days
- Recovery: use Azure Portal or CLI to restore previous versions

```bash
# List state versions
az storage blob list \
  --account-name stcloudopstfstate \
  --container-name tfstate \
  --prefix "dev/" \
  --include v \
  --auth-mode login \
  --output table
```

### 5. Multi-Team / Multi-Workspace Strategy

For organizations with multiple teams:

```
stcloudopstfstate
└── tfstate
    ├── team-platform/dev/terraform.tfstate
    ├── team-platform/prod/terraform.tfstate
    ├── team-app/dev/terraform.tfstate
    └── team-app/prod/terraform.tfstate
```

Or separate storage accounts per team for full isolation.

### 6. Shared Modules with State Data Sources

Teams can read each other's outputs using `terraform_remote_state`:

```hcl
data "terraform_remote_state" "network" {
  backend = "azurerm"
  config = {
    resource_group_name  = "rg-cloudops-tfstate"
    storage_account_name = "stcloudopstfstate"
    container_name       = "tfstate"
    key                  = "team-platform/prod/terraform.tfstate"
  }
}

# Use outputs
resource "azurerm_subnet" "app" {
  virtual_network_name = data.terraform_remote_state.network.outputs.vnet_name
}
```

### 7. Emergency State Operations

**Break a stuck lock:**
```bash
terraform force-unlock <LOCK_ID>
```

**Import existing resources:**
```bash
terraform import -var-file=environments/dev-eastus.tfvars module.vm.azurerm_linux_virtual_machine.this <resource-id>
```

**Move resources between states:**
```bash
terraform state mv module.old_name module.new_name
```

### 8. Security Hardening

- ✅ Shared access keys disabled (use RBAC only)
- ✅ TLS 1.2 minimum
- ✅ Public blob access disabled
- ✅ Versioning for audit trail
- ✅ Delete lock on resource group
- ✅ Zone-redundant storage (ZRS)
- ✅ Network rules (optional - add VNet/IP restrictions)

### 9. Monitoring

Enable diagnostic settings on the storage account to track state access:

```bash
az monitor diagnostic-settings create \
  --name "tfstate-audit" \
  --resource "/subscriptions/<sub>/resourceGroups/rg-cloudops-tfstate/providers/Microsoft.Storage/storageAccounts/stcloudopstfstate/blobServices/default" \
  --workspace <log-analytics-workspace-id> \
  --logs '[{"category":"StorageRead","enabled":true},{"category":"StorageWrite","enabled":true}]'
```
