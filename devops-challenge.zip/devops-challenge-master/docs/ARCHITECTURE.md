# Architecture

## High-Level Design

```
┌─────────────────────────────────────────────────────────────┐
│                     GitHub Actions CI/CD                      │
├──────────┬──────────────────────────────────┬───────────────┤
│    CI    │          Deploy Pipeline          │   Promote     │
│ (lint,   │  (plan → approve → apply)        │ (dev→test→    │
│  test,   │                                   │   prod)       │
│  scan)   │                                   │               │
└──────────┴──────────────────────────────────┴───────────────┘
                              │
              Service Principal Authentication
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                        Azure Cloud                            │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ Resource Group: rg-cloudops-{env}                     │   │
│  │                                                       │   │
│  │  ┌─────────────┐  ┌────────────────┐  ┌──────────┐  │   │
│  │  │    VNet      │  │  Key Vault     │  │ Recovery │  │   │
│  │  │  + Subnets   │  │ (CMK keys,     │  │ Services │  │   │
│  │  │  + NSGs      │  │  SSH keys)     │  │  Vault   │  │   │
│  │  │  + Routes    │  │                │  │          │  │   │
│  │  └─────────────┘  └────────────────┘  └──────────┘  │   │
│  │                                                       │   │
│  │  ┌─────────────┐  ┌────────────────┐  ┌──────────┐  │   │
│  │  │  Linux VM    │  │ Storage Acct   │  │   Load   │  │   │
│  │  │ + Data Disks │  │ + Containers   │  │ Balancer │  │   │
│  │  │ + Monitoring │  │ + Lifecycle    │  │ (Std/LB) │  │   │
│  │  │ + Backup     │  │ + CMK          │  │          │  │   │
│  │  └─────────────┘  └────────────────┘  └──────────┘  │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ Resource Group: rg-cloudops-tfstate (shared)          │   │
│  │  Storage Account: stcloudopstfstate (state backend)   │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

## Module Architecture

```
modules/
├── vnet/        → Network layer (VNet, Subnets, NSGs, Routes)
├── vm/          → Compute layer (Linux VM, Disks, Extensions)
└── storage/     → Storage layer (Account, Containers, Lifecycle)
```

Each module is:
- Independently testable (`terraform test`)
- Versioned with explicit provider constraints
- Reusable across environments via variable configuration

## Security Design

| Layer | Control |
|-------|---------|
| Authentication | Service Principal (via GitHub Secrets) |
| Encryption at rest | Customer-managed keys (Key Vault) |
| Encryption in transit | TLS 1.2 minimum |
| Network | NSGs deny-all default, service endpoints |
| VM | Trusted Launch (Secure Boot + vTPM) |
| Storage | Shared key disabled, RBAC-only |
| Secrets | Key Vault with RBAC access policies |

## HA & Scalability

- **Availability Zones**: VM placed in specific zone, Load Balancer spans zones 1-2-3
- **Storage redundancy**: ZRS (dev), GZRS (test), RAGZRS (prod)
- **Load Balancer**: Standard SKU, zone-redundant frontend
- **Backup**: Recovery Services Vault with daily policy

## Environment Strategy

| Environment | Region | CIDR | Purpose |
|-------------|--------|------|---------|
| dev | East US | 10.10.0.0/16 | Development & testing |
| test | East US 2 | 10.20.0.0/16 | Integration testing |
| prod | West Europe | 10.30.0.0/16 | Production workloads |

### Why Resource Groups (Not Subscriptions) for Environments

We use **separate Resource Groups per environment** (e.g., `rg-cloudops-dev`, `rg-cloudops-prod`) rather than separate Azure Subscriptions. Rationale:

| Factor | Resource Groups | Subscriptions |
|--------|----------------|---------------|
| **Isolation** | Logical separation (sufficient for most teams) | Hard billing/IAM boundary |
| **Cost** | Single subscription billing view | Per-subscription cost management |
| **Complexity** | Single provider config, state per env | Multiple provider aliases, complex auth |
| **Free-tier** | Works within one free subscription | Requires multiple subscriptions |
| **RBAC** | Scoped RG-level roles (Contributor per env) | Subscription-level roles needed |
| **State backend** | Shared backend, different state keys | Could use same or separate backends |

**Decision:** Resource Groups provide sufficient isolation for this challenge while keeping the Terraform configuration simple (single provider, single subscription). The state backend uses per-environment keys (`dev/terraform.tfstate`) for isolation. In a larger enterprise, you would escalate to separate subscriptions under a Management Group for hard cost/security boundaries.

**Scaling path:** If the organization grows, migrate to Azure Landing Zones with subscription-per-environment under a management group — the module structure and pipeline design remain identical, only the provider configuration changes.
